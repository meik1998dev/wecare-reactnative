export  const Colors = {
  yellow  : '#FFBD35',
  teal : '#3FA796' , 
  purpel  : '#8267BE' ,
  vintage : '#8843F2',
  white : '#fffdf8'
}
