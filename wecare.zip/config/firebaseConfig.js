// import firebase from '@react-native-firebase/app';
// // TODO: Add SDKs for Firebase products that you want to use
// // https://firebase.google.com/docs/web/setup#available-libraries

// // Your web app's Firebase configuration
// const firebaseConfig = {
//   apiKey: "AIzaSyB8VKt3Vrs5ee8M3Fj15OS_stPQ_3d37-Y",
//   authDomain: "wecare-579dd.firebaseapp.com",
//   databaseURL: "https://wecare-579dd-default-rtdb.firebaseio.com",
//   projectId: "wecare-579dd",
//   storageBucket: "wecare-579dd.appspot.com",
//   messagingSenderId: "707722534760",
//   appId: "1:707722534760:web:72a9ffc3207616321bc0dd",
//   measurementId: "G-K1G0WSL6BX"
// };

// // Initialize Firebase
// if (!firebase.apps.length) {
//    fb =   firebase.initializeApp(firebaseConfig);
// }
